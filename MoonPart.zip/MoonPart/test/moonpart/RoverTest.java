/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package moonpart;


import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author JINESH
 */
public class RoverTest {
    @Test
    public void testMoveForward() {
        Rover rover = new Rover();
        rover.moveForward();
        assertTrue(rover.getState() instanceof MoveForwardState);
    }

    @Test
    public void testMoveBackward() {
        Rover rover = new Rover();
        rover.moveBackward();
        assertTrue(rover.getState() instanceof MoveBackwardState);
    }

    @Test
    public void testStop() {
        Rover rover = new Rover();
        rover.moveForward();
        rover.stop();
        assertTrue(rover.getState() instanceof IdleState);

        rover.moveBackward();
        rover.stop();
        assertTrue(rover.getState() instanceof IdleState);
    }
}